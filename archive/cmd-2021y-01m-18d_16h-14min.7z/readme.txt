
console utilities serving the Workspace:

- cmdbit:
    - detect 32/64 bit of processes.

- garbage:
    - clean the Workspace.

- find_in.exe:
    - find files and directories.